

import disnake
from disnake.ext import commands


token = 'Сюда токен' #Выглядит как длинный набор символов
intents = disnake.Intents.all()
intents.members = True
bot = commands.Bot(command_prefix='.', intents=intents, help_command=None, activity= disnake.Game('Пельмени [.help1]', status = disnake.Status.online))


bot.load_extension('cogs.commands')
bot.load_extension('cogs.events')
bot.load_extension('cogs.assql2')
bot.load_extension('cogs.shop')
bot.load_extension('cogs.test')
bot.load_extension('cogs.vpi')
bot.load_extension('cogs.vpi_event')


print('Бот работает')
bot.run(token)
