import Paginator
import disnake
from disnake.ext import commands
import random
import sqlite3
from Paginator import CreatePaginator
from disnake.ui import Button, View
from disnake import Embed
from typing import List

conn2 = sqlite3.connect('vpi.db')
cursor2 = conn2.cursor()


def getclan(x: int):
    zz = cursor2.execute(f"select clanname from clans where ids = {x}").fetchone()[0]
    return zz
    print(zz)


def getprems(x: int):
    zz = cursor2.execute(f"select idtype from clans where ids = {x}").fetchone()[0]
    return zz


def ce(x):
    return cursor2.execute(x)


def getclannum(x: int):
    zz = cursor2.execute(f"select clanhave from territor where num = {x}").fetchone()[0]
    return zz
    print(zz)


def getgod(x: int):
    zz = cursor2.execute(f"select godid from gods where godid = {x}").fetchall()
    return zz


def emb(x):
    xx = x.split(',,')
    x = xx[0]
    b1 = xx[1]
    b2 = xx[2]
    b3 = xx[3]
    b4 = xx[4]

    embed = disnake.Embed(title=f'Описание клана. Часть 1')
    embed.add_field(name='Имя клана', value=f'{x}', inline=False)
    embed.add_field(name='Описание', value=b1, inline=False)
    embed.add_field(name='Столица', value=f'Имя [{b3}]\n Расположение [{b4}]', inline=False)
    if b2 == 'None':
        embed.set_thumbnail(
            url=f'https://cdn.discordapp.com/attachments/805846802750111818/1036181012830498836/rD2eVRRp2Xw.jpg')
    else:
        embed.set_thumbnail(url=f'{b2}')
    return embed


def manyembeds(x):
    x.split(',,')
    []


def emb2(x1, x2, x3, x4, x5, x6):
    embed = disnake.Embed(title=f'Описание клана. Часть 2')
    embed.add_field(name=f'Первый ресурс', value=f'{x1}', inline=False)
    embed.add_field(name=f'Второй ресурс', value=f'{x2}', inline=False)
    embed.add_field(name=f'Третий ресурс', value=f'{x3}', inline=False)
    embed.add_field(name=f'Армия', value=f'{x4}', inline=False)
    embed.add_field(name=f'Тяжелые единицы', value=f'{x5}', inline=False)
    embed.add_field(name=f'Вундерфавли', value=f'{x6}', inline=False)
    return embed


class VPI(commands.Cog):
    def __int__(self, bot=commands.Bot):
        self.bot = bot

    def custom_cooldown(message):

        return commands.Cooldown(1, 60*60)

    def attcd(message):
        cc1 = ce(f"select townnum from lidtown where townid ={message.author.id}").fetchall()

        return commands.Cooldown(len(cc1),20)

    def bucketcd(message):
        ccc =ce(f"select idtype from clans where clanname = '{getclan(message.author.id)}'").fetchone()[0]
        return ccc

    @commands.slash_command()
    async def vpihelp(self, ctx, x=commands.Param(name='select', choices=['Правила', 'Команды'])):
        if x == 'Правила':
            em1 = Embed(title='Правила ВПИ',
                        description='ВПИ - Военно Политическая Игра где происходит РП взаимодействите персонажей на определнной территории. Игроки могут друг с другом торговать или же привнести в вечный мир пламя воины\n'
                                    'Вот список правил...')

            em1.add_field(name='1-е Правило', value='Нельзя совершать атаки не объявляя войну', inline=False)
            # em1.add_field(name='',value='')
            await ctx.send(embed=em1)
        if x == 'Команды':
            em1 = Embed(title='Команды ВПИ', description='Список команд')

            em1.add_field(name='`/annex [номер территории]`', value='Захватить ничейную территорию', inline=False)
            em1.add_field(name='`/claninfo [имя клана]`', value='Получить информацию клана', inline=False)
            em1.add_field(name='`/collect`', value='Собрать ресурсы', inline=False)

            em2 = Embed(title='Команды ВПИ', description='Список команд для Лидеров и заместителей')
            em2.add_field(name='`/annex [номер территории]`', value='Захватить выбранную территорию')
            em2.add_field(name='`/attack [номер территории]`', value='Атаковать выбранную территорию', inline=False)
            em2.add_field(name='`/addtoclan [пинг]`', value='Добавить человека в клан', inline=False)
            em2.add_field(name='`/namecap`', value='Назвать свою столицу')
            em2.add_field(name='`/promote`', value='Повысить участника клана до заместителя')
            em2.add_field(name='`/makezav [номер территории] [выбор]`', value='Создать завод выбранной территории')
            embeds = [em1, em2]
            await ctx.send(embed=embeds[0], view=CreatePaginator(embeds, ctx.author.id))

    @commands.slash_command()
    @commands.dynamic_cooldown(custom_cooldown,commands.BucketType.user)
    async def attack(self, ctx, x: int):
        jj = ce(f"select zavodnum from zavod where zavodnum = {x}").fetchone()[0]
        jj1 = ce(f"select zavodtype from zavod where zavodnum = {jj}")
        if getprems(ctx.author.id) <= 0:
            await ctx.send(embed=disnake.Embed(title='Ой', description='Только лидер или заметитель может атаковать'))
        else:
            t = cursor2.execute(f"select town from territor where num = {x}").fetchone()[0]
            if t == 0:
                c = cursor2.execute(f"select army1 from ress where clanres = '{getclan(ctx.author.id)}'").fetchone()[0]
                cc = cursor2.execute(f"select army1 from ress where clanres = '{getclannum(x)}'").fetchone()[0]
                print(cc)
                print(getclannum(x))
                print(c)
                if c > 1.15 * cc:
                    hhh = random.randint(1, 100)
                    print(hhh)
                    if hhh > 60:  # Если армия атакующего на 15% больше армии защитника. Если выпадает больше 60, то победа
                        cursor2.execute(
                            f"update ress set army1 = {int(c * 0.7)} where clanres = '{getclan(ctx.author.id)}'")
                        cursor2.execute(f"update ress set army1 = {int(cc * 0.8)} where clanres = '{getclannum(x)}'")
                        cursor2.execute(f"update territor set clanhave = '{getclan(ctx.author.id)}' where num  ={x}")
                        cursor2.execute(f"update upgrades set upclan = '{getclan(ctx.author.id)}' where upnum = {x}")
                        embed = disnake.Embed(title='ПОБЕДА',
                                              description=f'Ваши потери {int(c - (c * 0.7))}\n Потери противника {int(cc - (cc * 0.7))}')
                        if jj is not None:
                            ce(f"update zavod set clanzavod = '{getclan(ctx.author.id)}' where zavodnum = {x}")

                            if jj1 == 1:
                                embed.add_field(name='Получен завод Артиллерии!', value=x, inline=False)
                            if jj1 == 2:
                                embed.add_field(name='Получен завод Cупероружия!', value=x, inline=False)
                        else:
                            pass
                        conn2.commit()
                        await ctx.send(embed=embed)

                    else:
                        cursor2.execute(
                            f"update ress set army1 = {int(c * 0.8)} where clanres = '{getclan(ctx.author.id)}'")
                        cursor2.execute(f"update ress set army1 = {int(cc * 0.7)} where clanres = '{getclannum(x)}'")
                        conn2.commit()
                        await ctx.send(embed=disnake.Embed(title='ПОРАЖЕНИЕ',
                                                           description=f'Ваши потери {int(c - (c * 0.8))}\n Потери противника {int(cc - (cc * 0.7))}'))
                else:  # Если армия атакующего меньше или примерно равна армии защитника защитника. Если выпадает больше 70, то победа
                    hhh = random.randint(1, 100)
                    print(hhh)
                    if hhh > 70:
                        cursor2.execute(
                            f"update ress set army1 = {int(c * 0.8)} where clanres = '{getclan(ctx.author.id)}'")
                        cursor2.execute(f"update ress set army1 = {int(c * 0.8)} where clanres = '{getclannum(x)}'")
                        cursor2.execute(f"update territor set clanhave = '{getclan(ctx.author.id)}' where num  ={x}")
                        cursor2.execute(f"update upgrades set upclan = '{getclan(ctx.author.id)}' where upnum = {x}")
                        conn2.commit()
                        embed = disnake.Embed(title='ПОБЕДА',
                                              description=f'Ваши потери {int(c - (c * 0.8))}\n Потери противника {int(cc - (cc * 0.8))}')
                        if jj is not None:
                            ce(f"update zavod set clanzavod = '{getclan(ctx.author.id)}' where zavodnum = {x}")
                            if jj1 == 1:
                                embed.add_field(name='Получен завод Артиллерии!', value=x, inline=False)
                            if jj1 == 2:
                                embed.add_field(name='Получен завод Cупероружия!', value=x, inline=False)
                        else:
                            pass
                        await ctx.send(embed=embed)
                    else:
                        cursor2.execute(
                            f"update ress set army1 = {int(c * 0.8)} where clanres = '{getclan(ctx.author.id)}'")
                        cursor2.execute(f"update ress set army1 = {int(cc * 0.7)} where clanres = '{getclannum(x)}'")
                        conn2.commit()
                        await ctx.send(embed=disnake.Embed(title='ПОРАЖЕНИЕ',
                                                           description=f'Ваши потери {int(c - (c * 0.8))}\n Потери противника {int(cc - (cc * 0.8))}'))
            else:
                await ctx.send(embed=disnake.Embed(title='Ой',
                                                   description='На территории находиться город и его можно взять только Артиллерией или супероружием`'))

    @commands.slash_command()
    async def createart(self, ctx, x=None):
        c1 = ce(
            f"select zavodtype from zavod where clanzavod = '{getclan(ctx.author.id)}' and zavodtype = {1}").fetchall()
        c2 = ce(f"select army2 from ress where clanres = '{getclan(ctx.author.id)}'").fetchone()[0]
        if getprems(ctx.author.id) > 0:
            if x is None:

                if c1 != []:
                    ce(f"update ress set army2 = {c2 + len(c1)} where clanres = '{getclan(ctx.author.id)}'")
                    await ctx.send(embed=Embed(title='Артиллерия', description=f'{len(c1)} Артиллерий упешно создано!'))
            else:
                if c1 != []:
                    if c1 >= x:
                        ce(f"update ress set army2 = {c2 + x}")
                    else:
                        await ctx.send(embed=Embed(title='Ой',
                                                   description=f'У вас недостаточно заводов чтобы сделать {x} Артиллерии'))
        else:
            await ctx.send(embed=Embed(title='Ой ой', description='Недостаточно прав'))

    @commands.slash_command()
    async def createclan(self, ctx,
                         y: disnake.Member = commands.Param(name='ping', description='Пинг человека кому создать клан'),
                         x: int = commands.Param(name='num', description='Номер территории'), *,
                         z=commands.Param(name='name', description='Имя вашего клана')):
        try:
            if getgod(ctx.author.id):
                cursor2.execute(
                    f"insert into clans(clanname, ids, idtype,opis,clanurl) values ('{z}', {y.id},{2},'None','None')")
                cursor2.execute(
                    f"update territor set clanhave = '{z}', town = {1}, cap ={1}, townname ='None' where num = {x}")
                cursor2.execute(
                    f"insert into ress(clanres, res1, res2, res3, army1,army2,army3) values ('{z}',{0},{0},{0},{0},{0},{0})")
                ce(f"insert into lidtown (townnum, townid, townclan) values ({x},{y.id},'{z}')")
                conn2.commit()
                await ctx.send(embed=disnake.Embed(title='Создание клана', description=f'Клан {z} успешно создан!'))
            else:
                await ctx.send(
                    embed=disnake.Embed(title='Создание клана', description=f'Недостаточно прав для создания клана'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command(description='Получить информацию о клане')
    async def claninfo(self, ctx, x=commands.Param(name='name', description='Имя клана')):
        b1 = cursor2.execute(f"select opis from clans where clanname = '{x}'").fetchone()[0]
        b2 = cursor2.execute(f"select clanurl from clans where clanname = '{x}'").fetchone()[0]
        b3 = cursor2.execute(f"select townname from territor where clanhave = '{x}' and cap = {1}").fetchone()[0]
        b4 = cursor2.execute(f"select num from territor where cap = {1} and clanhave ='{x}'").fetchone()[0]

        x1 = cursor2.execute(f"select res1 from ress where clanres = '{x}'").fetchone()[0]
        x2 = cursor2.execute(f"select res2 from ress where clanres = '{x}'").fetchone()[0]
        x3 = cursor2.execute(f"select res3 from ress where clanres = '{x}'").fetchone()[0]
        x4 = cursor2.execute(f"select army1 from ress where clanres = '{x}'").fetchone()[0]
        x5 = cursor2.execute(f"select army2 from ress where clanres = '{x}'").fetchone()[0]
        x6 = cursor2.execute(f"select army3 from ress where clanres = '{x}'").fetchone()[0]

        embed = disnake.Embed(title=f'Описание клана')
        embed.add_field(name='Имя клана', value=f'{x}', inline=False)
        embed.add_field(name='Описание', value=b1, inline=False)
        embed.add_field(name='Столица', value=f'Имя [{b3}]\n Расположение [{b4}]', inline=False)
        if b2 == 'None':
            embed.set_thumbnail(
                url=f'https://cdn.discordapp.com/attachments/805846802750111818/1036181012830498836/rD2eVRRp2Xw.jpg')
        else:
            embed.set_thumbnail(url=f'{b2}')
        embeds = []

        embeds.append(emb(f"{x},,{b1},,{b2},,{b3},,{b4}"))
        embeds.append(emb2(x1, x2, x3, x4, x5, x6))
        print(embeds)
        await ctx.send(embed=embeds[0], view=CreatePaginator(embeds, ctx.author.id))

    @commands.slash_command(description='Сделать описание клана')
    async def clanopis(self, ctx, *, x=commands.Param(name='text', description='Текст описания клана')):
        if int(getprems(ctx.author.id)) == 2:
            cursor2.execute(f"update clans set opis = '{x}' where clanname = '{getclan(ctx.author.id)}' ")
            conn2.commit()
            await ctx.send(
                embed=disnake.Embed(title='Ура!', description=f'Описание для клана {getclan(ctx.author.id)} готово!'))
        else:
            await ctx.send(
                embed=disnake.Embed(title='Ой', description=f'{ctx.author.mention}, недостаточно прав'))

    @commands.slash_command()
    async def namecap(self, ctx, *, x=commands.Param(name='text', description='Имя столицы')):
        if int(getprems(ctx.author.id)) == 2:
            cursor2.execute(f"update territor set townname ='{x}' where clanhave = '{getclan(ctx.author.id)}'")
            conn2.commit()
        else:
            await ctx.send(
                embed=disnake.Embed(title='Ой', description=f'{ctx.author.mention}, недостаточно прав'))

    @commands.command(description='Сделать картиночку')
    async def clanurl(self, ctx):
        if getprems(ctx.author.id) == 2:
            cursor2.execute(
                f"update clans set clanurl = '{ctx.message.attachments[0]}' where clanname = '{getclan(ctx.author.id)}'")
            conn2.commit()
            await ctx.send(
                embed=disnake.Embed(title='Аватар клана',
                                    description=f'Аватар для клана {getclan(ctx.author.id)} успешно поставлен!'))
        else:
            await ctx.send(
                embed=disnake.Embed(title='Ой',
                                    description=f'{ctx.author.mention}, недостаточно прав. Только лидер на это способен'))

    @commands.slash_command()
    async def makenums(self, ctx, x: int = commands.Param(name='num', description='Колличество клеточек')):
        try:
            if getgod(ctx.author.id):
                ll = cursor2.execute(f"select num from territor").fetchall()
                if not ll:
                    for i in range(x):
                        cursor2.execute(
                            f"insert into territor(num , clanhave, res, town,cap,townname) values ({i}, 'None', {0}, {0},{0},'None')")
                        cursor2.execute(
                            f"insert into upgrades(upclan, upnum, restype, upvalue) values ('None', {i},{0},{0})")
                        conn2.commit()
                    await ctx.send(
                        embed=disnake.Embed(title='Генерация территории',
                                            description=f'{x} Территорий успешно созданы! '))
                else:
                    await ctx.send(
                        embed=disnake.Embed(title='Генерация территории', description='Территория уже создана!'))
            else:
                await ctx.send(embed=disnake.Embed(title='Генерация территории', description='Недостаточно прав.'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command()
    async def maketown(self,ctx,x = commands.Param(name='num',description='Номер города')):
        ce(f"update territor set clanhave = '{getclan(ctx.author.id)}' where num = {x}")
        ce(f"insert into lidtown (townnum, townid, townclan) values ({x},{ctx.author.id},'{getclan(ctx.author.id)}')")

        conn2.commit()

    @commands.slash_command()
    async def addtoclan(self, ctx, y: disnake.Member = commands.Param(name='ping',
                                                                      description='Пинг человека которого надо добавить')):
        try:
            cursor2.execute(f"select clanname from clans where ids =  {y.id}")
            zz = cursor2.fetchall()
            if not zz:
                cursor2.execute(
                    f"insert into clans(clanname, ids, idtype) values ('{getclan(ctx.author.id)}', {y.id},{0})")
                await ctx.send(embed=disnake.Embed(title=f'Ура!',
                                                   description=f'{y.mention} теперь в рядах {getclan(ctx.author.id)}!'))
                conn2.commit()
            else:
                await ctx.send(
                    embed=disnake.Embed(title='Ой ой', description=f'Кажется {y.mention} уже есть в другом клане!'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command()
    async def addmember(self, ctx, y: disnake.Member = commands.Param(name='ping',
                                                                      description='Пинг человека которого надо добавить'),
                        *, x=commands.Param(name='clan',
                                            description='Имя клана[Пишите название полнстью с учётом капса]')):
        try:
            if getgod(ctx.author.id):
                cursor2.execute(f"select clanname from clans where ids =  {y.id}")
                zz = cursor2.fetchall()
                if not zz:
                    cursor2.execute(f"insert into clans(clanname, ids, idtype) values ('{x}', {y.id},{0})")
                    await ctx.send(embed=disnake.Embed(title=f'Ура!', description=f'{y.mention} теперь в рядах {x}!'))
                    conn2.commit()
                else:
                    await ctx.send(
                        embed=disnake.Embed(title='Ой ой', description=f'Кажется {y.mention} уже есть в другом клане!'))
            else:
                await ctx.send(embed=Embed(title='Ой', description='Вы не бог.'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command()
    async def godpromote(self, ctx, y: disnake.Member):
        try:
            if ctx.author.id == 310730780303294475:
                cursor2.execute(f"insert into gods(godid) values ({y.id})")
                conn2.commit()
                await ctx.send(
                    embed=disnake.Embed(title='MADE IN HAVEN', description=f'{y.mention} повышен до звания БОГА'))
            else:
                await ctx.send(embed=disnake.Embed(title='СТОЯТЬ!', description=f'Вы не Верховный Бог.'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command()
    async def promote(self, ctx, y: disnake.Member = commands.Param(name='ping',description='Пинг того, кого повысить в вашем клане')):
        try:
            if getprems(ctx.author.id) == 2:
                uu = ce(f"select clanname from clans where ids = {y.id}").fetchone()[0]
                uu1 = ce(f"select clanname from clans where ids = {ctx.author.id}").fetchone()[0]
                if uu == uu1:
                    cursor2.execute(f"update clans set idtype =  {1} where ids = {y.id}")
                    conn2.commit()
                    await ctx.send(embed=disnake.Embed(title='Ура!', description=f'{y.mention} Повышен!'))
                else:
                    await ctx.send(embed = Embed(title='Ой ой',description='Вы можете повышать только членов своего клана'))
            else:
                await ctx.send(
                    embed=disnake.Embed(title='Ой', description=f'Недостаточно прав. Это может делать только лидер'))
        except Exception as e:
            await ctx.send(embed=disnake.Embed(title='Блять!', description=f'Ошибка {e}'))

    @commands.slash_command(description='Захватить ничейную территорию')
    @commands.dynamic_cooldown(attcd,commands.BucketType.user)
    async def annex(self, ctx, x: int = commands.Param(name='num',
                                                       description='Номер ничейной территории которую вы хотите захватить')):
        z = cursor2.execute(f"select clanhave from territor where num  ={x}").fetchone()[0]
        if z == 'None':
            cursor2.execute(f"update territor set clanhave = '{getclan(ctx.author.id)}' where num = {x} ")
            cursor2.execute(f"update upgrades set upclan == '{getclan(ctx.author.id)}' where upnum = {x}")
            conn2.commit()
            await ctx.send(embed = Embed(title='Аннексирование',description=f'Территория {x} успешно захвачена!'))
        else:
            await ctx.send(embed=disnake.Embed(title=f'Ой ой', description='Территория уже занята!'))

    @commands.slash_command()
    async def makeres(self, ctx, y, x):
        cursor2.execute(f"update territor set res = {int(x)} where num = {int(y)}")
        cursor2.execute(f"update upgrades set restype ={int(x)} where upnum = {int(y)}")
        conn2.commit()

    @commands.slash_command()  # lambda ctx: ctx.author.id
    async def upgrade(self, ctx, x=commands.Param(name='num', description='Номер территории на которой надо улучшить')):
        if getprems(ctx.author.id) > 0:
            zz = cursor2.execute(f"select upvalue from upgrades where upnum = {int(x)}").fetchone()[0]
            cursor2.execute(f"update upgrades set upvalue = {zz + 1} where upnum = {int(x)}")
            conn2.commit()
            await ctx.send(
                embed=disnake.Embed(title='Улучшение', description=f'Шахта на территории {x} успешно улучшена!'))
        else:
            await ctx.send(embed=disnake.Embed(title='Улучшение',
                                               description=f'Недостаточно прав. Только лидер или заместитель может это делать'))

    @commands.slash_command()
    @commands.dynamic_cooldown(custom_cooldown, commands.BucketType.user)
    async def collect(self, ctx):
        try:
            f = []
            ff = []

            r1 = random.randint(1, 100)
            r2 = random.randint(1, 2)
            r3 = random.randint(2, 3)
            cursor2.execute(f"select num from territor where clanhave = '{getclan(ctx.author.id)}' and res > {0}")
            zz = cursor2.fetchall()
            for x in range(len(zz)):
                f.append(zz[x][0])
            bbb = cursor2.execute(f"select res2 from ress where clanres  ='{getclan(ctx.author.id)}'").fetchone()
            bbb = bbb[0]
            bbb1 = cursor2.execute(f"select res3 from ress where clanres  ='{getclan(ctx.author.id)}'").fetchone()
            bbb1 = bbb1[0]
            bbb2 = cursor2.execute(f"select res1 from ress where clanres = '{getclan(ctx.author.id)}'").fetchone()
            bbb2 = bbb2[0]
            embed = disnake.Embed(title=f'Ресурсы получены!')
            vv = random.randint(1, 100)
            bbb3 = cursor2.execute(f"select army1 from ress where clanres = '{getclan(ctx.author.id)}'").fetchone()
            bbb3 = bbb3[0]
            cursor2.execute(
                f"update ress set res1 = {bbb2 + r1}, army1 = {bbb3 + vv} where clanres = '{getclan(ctx.author.id)}'")
            conn2.commit()
            embed.add_field(name='Первый ресурс', value=r1, inline=False)
            embed.add_field(name='Армия', value=vv, inline=False)
            if getprems(ctx.author.id) > 0:

                for i in range(len(f)):
                    cc = cursor2.execute(f"select upvalue from upgrades where upnum = {f[i]}").fetchone()
                    cc = cc[0]
                    ff.append(cc)
                for ii in range(len(ff)):
                    aa = cursor2.execute(f"select restype from upgrades where upnum = {f[ii]}").fetchone()
                    aa = aa[0]  # Тип руды

                    if ff[ii] == 0:
                        pass
                    if ff[ii] == 1:
                        if aa == 1:
                            cursor2.execute(
                                f"update ress set res2={int(bbb + r2)} where clanres  ='{getclan(ctx.author.id)}'")
                            conn2.commit()
                            embed.add_field(name='Второй ресурс', value=int(r2), inline=False)
                        if aa == 2:
                            cursor2.execute(
                                f"update ress set res3={int(bbb1 + r2)} where clanres  ='{getclan(ctx.author.id)}'")
                            conn2.commit()
                            embed.add_field(name='Третий ресурс', value=int(r2), inline=False)
                    if ff[ii] == 2:
                        if aa == 1:
                            cursor2.execute(
                                f"update ress set res2={bbb + r2 + ff[ii] - 1} where clanres  ='{getclan(ctx.author.id)}'")
                            conn2.commit()
                            embed.add_field(name='Второй ресурс', value=int(r3), inline=False)
                        if aa == 2:
                            cursor2.execute(
                                f"update ress set res3={bbb1 + r2 + ff[ii] - 1} where clanres  ='{getclan(ctx.author.id)}'")
                            conn2.commit()
                            embed.add_field(name='Третий ресурс', value=int(r3), inline=False)
                    else:
                        pass

            await ctx.send(embed=embed)
        except Exception(disnake.ext.commands.errors.CommandOnCooldown) as e:
            await ctx.send(e)

    @commands.slash_command()
    @commands.dynamic_cooldown(custom_cooldown, commands.BucketType.user)
    async def siege(self, ctx, y: int = commands.Param(name='num',description='Номер территории с городом'), x=commands.Param(name='type', choices=['Артиллерия', 'Супероружие'])):
        cc=0
        if getprems(ctx.author.id) > 0:
            ce(f"select town from territor where num = {y}")
            if x == 'Супероружие':
                c1 = ce(f"select army3 from ress where clanres = '{getclan(ctx.author.id)}' ").fetchone()[0]
                if c1 > 0:
                    x = random.randint(1, 2)
                    if x == 1:
                        ce(f"update ress set army3 == {c1 - 1} where clanres = '{getclan(ctx.author.id)}'")
                        conn2.commit()
                    if x == 2:
                        pass

            if x == 'Артиллерия':
                c1 = ce(f"select army2 from ress where clanres == '{getclan(ctx.author.id)}' ").fetchone()[0]
                if c1>0:
                    x = random.randint(1,2)
                    if x == 1:
                        ce(f"update ress set army2 == {c1 - 1} where clanres = '{getclan(ctx.author.id)}'")
                        conn2.commit()
                        cc= x
                    if x == 2:
                        cc = 0
                        pass
                    c = random.randint(1,100)
                    if c > 30:
                        ce(f"update territor set clanhave = '{getclan(ctx.author.id)}' where num = {x}")
                        ce(f"update lidtown set townclan = '{getclan(ctx.author.id)}',townid = {ctx.author.id} where townnum = {x}")

                        await ctx.send(embed = Embed(title = 'УСПЕХ',description='Артиллерия успещно выполнила свою задачу').add_field(name=f'Потеряно Артилерии',value=cc))
                    else:
                        await ctx.send(embed = Embed(title='НЕУДАЧА',description='Артиллерия не помогла захватить город').add_field(name='Потеряно Артиллерии',value=f'{cc}'))
        else:
            ctx.send(Embed(title='Ой', description='Недостаточно прав'))

    @commands.slash_command()
    async def makezav(self, ctx, y: int, x=commands.Param(name='type', choices=['Артиллерия', 'Супероружие'])):
        if getprems(ctx.author.id) > 0:
            xx = ce(f"select zavodtype from zavod where zavodnum =={y}").fetchall()
            if x == 'Артиллерия':
                if not xx:
                    ce(f"insert into zavod(clanzavod,zavodnum,zavodtype) values ('{getclan(ctx.author.id)}',{y},{1})")
                    conn2.commit()
                    await ctx.send(embed=Embed(title='Завод', description='Завод Артиллерии построен!'))
                else:
                    await ctx.send(embed=Embed(title='Ой', description='На этой территории есть завод!'))

            if x == 'Супероружие':
                if xx is None:
                    ce(f"insert into zavod(clanzavod,zavodnum,zavodtype) values ('{getclan(ctx.author.id)}',{y},{2})")
                    conn2.commit()
                    await ctx.send(embed=Embed(title='Завод', description='Завод Супероружия построен!'))
                else:
                    await ctx.send(embed=Embed(title='Ой', description='На этой территории есть завод!'))
        else:
            await ctx.send(embed=Embed(title='Ой', description='Недостаточно прав'))


def setup(bot: commands.Bot):
    bot.add_cog(VPI(bot))
    print('Ког ВПИ запущен')
