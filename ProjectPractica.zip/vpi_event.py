import disnake
from disnake.ext import commands
import random
import sqlite3

conn2 = sqlite3.connect('vpi.db')
cursor2 = conn2.cursor()


class VPIEvents(commands.Cog):
    def __init__(self, bot=commands.Bot):
        self.bot = bot



    @commands.Cog.listener()
    async def on_ready(self):
        cursor2.execute("""create table if not exists clans(
        clanname text,
        ids int,
        idtype int,
        opis text,
        clanurl text)""")

        cursor2.execute("""create table if not exists territor(
        num int,
        clanhave text,
        res int,
        town int,
        cap int,
        townname text
        )""")
        cursor2.execute("""create table if not exists ress(
        clanres text,
        res1 int,
        res2 int,
        res3 int,
        army1 int,
        army2 int,
        army3 int)""")  # [res1, res2, res3] - Ресурсы . [army1, army2, army3]- Армия[Лёгкие войска, Тяжелые войска, Вундерваффе] .

        cursor2.execute("""create table if not exists upgrades(
        upclan text,
        upnum int,
        restype int,
        upvalue int

        )""")  # upclan - Имя клана . upnum - Номер территории на которой есть апгрейд . upvalue - Уровень апгрейда

        cursor2.execute("""create table if not exists artef(
        clanart text,
        artname text)""") #Артефакты - Выдаются при выполнении задачи ивента. При использовании могут тратиться или нет(Зависит от типа артефакта). Артефакты-расходники дают [ресурсы или армию или улучшения]

        cursor2.execute("""create table if not exists gods(
        godid int)""")

        cursor2.execute("""create table if not exists zavod(
        clanzavod text,
        zavodnum int,
        zavodtype int)""")

        cursor2.execute("""create table if not exists lidtown(
        townnum int,
        townid int,
        townclan text)""")# townnum - Место где расположен город . townnid - ID держателя города . townclan - Принадлежность держателя города к клану

        conn2.commit()


def setup(bot: commands.Bot):
    bot.add_cog(VPIEvents(bot))
    print('Ког ВПИ2 запущен')
